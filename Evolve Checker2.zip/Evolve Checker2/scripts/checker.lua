require('addon')

local events = require('samp.events')
local requests = require('requests')
local encoding = require('encoding')

encoding.default = 'CP1251'
local u8 = encoding.UTF8

BOT = {
    SPECTATING = 0,
    HOUSE = 0,
    HOUSE_COORD = {1154.53, -1766.76, 16.59},
    BYPASS = false,
    BYPASSING = true,
    PASSWORD = 'Aezakmi228',
    SPAWN = {1154.53, -1766.76, 16.59}
};

TELEGRAM = {
    CHAT_ID = 612687438,
    TOKEN = '5672408159:AAGDK68i2-Z5m0xFn0iWns4eNMO7Z1F2Ob0'
};

function SCMF(...) return print(string.format('[Evolve-Checker]: %s', string.format(...))) end
function setWindowTitleFormat(...) return setWindowTitle(string.format('[Evolve-Checker] %s', string.format(...))) end

function AnsiToUtf8(s)
    return u8(s, 'CP1251')
end

function sendTelegram(text)
    if TELEGRAM.CHAT_ID == -1 or TELEGRAM.TOKEN == 'STRING' then 
        return SCMF('������� ��������� ���������!')
    end
    
    local URL = string.format('https://api.telegram.org/bot%s/sendMessage', TELEGRAM.TOKEN)
    local DATA = {
        ['chat_id'] = TELEGRAM.CHAT_ID,
        ['text'] = AnsiToUtf8(text)..'\nCreated by \u{2764}\u{FE0F}'
    }
    
    local headers = {
        ["user-agent"] = "Mozilla/5.0",
        ['Content-Type'] = 'application/json'
    }
    
    local RESULT, RESPONSE = pcall(function()
        return requests.post{
            url = URL,
            headers = headers,
            data = DATA
        }
    end)
    
    if RESULT then
        SCMF('Sended')
    else
        SCMF('Error: %s', RESPONSE)
    end
end

function sendClickTextdraw(id)
    local BS = bitStream.new()
    BS:writeUInt16(id)
    BS:sendRPC(83)
    BS:reset()
end

function events.onSendRequestSpawn()  
    if BOT.BYPASSING then 
        return false  
    end
end

function events.onSendSpawn() 
    if BOT.BYPASSING then 
        return false  
    end
end

function events.onTogglePlayerSpectating(state)
    if not state then
        newTask(function()
            BS = bitStream.new()
            BS:writeUInt16(1)
            BS:sendRPC(128)
            BS:reset()
            wait(1000) 
            BS = bitStream.new()
            BS:sendRPC(52)
            BS:reset()
            BS = bitStream.new()
            BS:sendRPC(129)
            BS:reset()
            SCMF('Exploit +')
            BOT.BYPASSING = false
            wait(1000)
            BOT.BYPASS = true
        end)
    end
    return false
end

function events.onShowDialog(dialogId, style, title, button1, button2, text)
    if title:find('���� ������') then 
        sendDialogResponse(dialogId, 1, -1, BOT.PASSWORD)
        SCMF('��������������, ������: %s', BOT.PASSWORD)
    end
end

function events.onSetRaceCheckpoint(type, position, nextPosition, size)
    BOT.HOUSE_COORD[1] = position.x
    BOT.HOUSE_COORD[2] = position.y
    BOT.HOUSE_COORD[3] = position.z
end

function events.onSetSpawnInfo(team, skin, unk, position, rotation, weapons, ammo)
    BOT.SPAWN[1] = position.x 
    BOT.SPAWN[2] = position.y
    BOT.SPAWN[3] = position.z
end

function events.onSetMapIcon(iconId, position, type, color, style)
    if BOT.BYPASS then 
        if type == 31 then 
            sendTelegram(string.format('������ ��� � �����!\n�������������� ���� ����: %d\n����������: %d, %d, %d', BOT.HOUSE, position.x, position.y, position.z))
        end
    end
end

function events.onShowTextDraw(id, data)
    if id == 214 then 
        sendClickTextdraw(id)
    end
end

function events.onSendPlayerSync(data)
    if BOT.BYPASSING then
        sendSpectator(BOT.SPAWN[1], BOT.SPAWN[2], BOT.SPAWN[3])
        return false 
    else
        return false 
    end
end

function sendSpectator(x, y, z)
	local BS = bitStream.new()
	BS:writeInt8(212)
	BS:writeInt16(0) -- LeftRightKeys
	BS:writeInt16(0) -- UpDownKeys
	BS:writeInt16(0) -- keysData
	BS:writeFloat(x) -- position x
	BS:writeFloat(y) -- position y
	BS:writeFloat(z) -- position z
	BS:sendPacket()
	BS:reset()
end

function sendOnfoot(x, y, z)
    local BS = bitStream.new()
    local moveSpeed = {0, 0, 0}
    local surfingOffsets = {0, 0, 0}
    BS:writeInt8(207)
    BS:writeInt16(0) -- LeftRightKeys
	BS:writeInt16(65408) -- UpDownKeys
	BS:writeInt16(0) -- keysData
    BS:writeFloat(x) -- position x
    BS:writeFloat(y) -- position y
    BS:writeFloat(z) -- position z
    for i = 1, 4 do 
        local quaternion = {getBotQuaternion()}
        BS:writeFloat(quaternion[i]) 
    end
    BS:writeInt8(getBotHealth()) -- hp
	BS:writeInt8(getBotArmor()) -- armour
    BS:writeInt8(0) -- weapon
	BS:writeInt8(0) -- SpecialAction
    for i = 1, 3 do 
        BS:writeFloat(moveSpeed[i]) -- movespeed 
    end
    for i = 1, 3 do 
        BS:writeFloat(surfingOffsets[i]) -- surfingOffsets
    end
	BS:writeInt16(0) -- surfingVehicleId 
    BS:writeInt16(1195) -- anim id
	BS:writeInt16(32776) -- anim flag
	BS:sendPacket()
	BS:reset()
end

function findThread()
    while true do wait(0)
        if isBotConnected() then 
            setWindowTitleFormat('Checking house: %d | Position %f %f %f', BOT.HOUSE, BOT.HOUSE_COORD[1], BOT.HOUSE_COORD[2], BOT.HOUSE_COORD[3])
            if BOT.BYPASS and not BOT.BYPASSING then 
                sendInput(string.format('/findhouse %d', BOT.HOUSE))
                for i = 1, 3 do 
                    sendSpectator(BOT.HOUSE_COORD[1], BOT.HOUSE_COORD[2], BOT.HOUSE_COORD[3])
                end
                wait(1000)
                BOT.HOUSE = BOT.HOUSE + 1
                if BOT.HOUSE > 950 then 
                    SCMF('�������� ��� ����, ����������')
                    BOT.HOUSE = 0;
                end
            end
        else
            if BOT.BYPASS then 
                BOT.HOUSE = 0;
                BOT.BYPASS = false;
                BOT.BYPASSING = true;
            end
        end
    end
end

function onLoad()
	SCMF('������� �������� v1.0 [t.me/quesada_team]')
    newTask(findThread)
    sendTelegram('��� �������!')
end